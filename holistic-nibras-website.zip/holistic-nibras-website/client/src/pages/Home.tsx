import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Mail, MapPin, Phone, BookOpen, Users, Sparkles, ArrowRight, CheckCircle, Star } from "lucide-react";

/**
 * Design Philosophy: Warm Minimalism with Educational Focus
 * Color Palette: Sage Green (#6B8E7F), Soft Cream (#FBF8F3), Burnt Orange (#C85A3A)
 * Typography: Playfair Display (headings), Poppins (CTAs), Inter (body)
 * Layout: Asymmetric, breathing whitespace, subtle animations
 */

export default function Home() {
  const reviews = [
    {
      name: "Mina Aziz",
      text: "This is one of the best education centres I have sent my child to. Definitely recommended.",
      rating: 5
    },
    {
      name: "Junaid Ahmad",
      text: "They provided my child a safe learning environment where he easily got along with students.",
      rating: 5
    },
    {
      name: "Fatima Khan",
      text: "Excellent teaching methodology and very supportive staff. My daughter has shown remarkable improvement.",
      rating: 5
    },
    {
      name: "Ahmed Hassan",
      text: "The holistic approach to education really sets this school apart. Highly professional and caring.",
      rating: 5
    },
    {
      name: "Sara Malik",
      text: "Outstanding facilities and dedicated teachers. Our son loves going to school every day!",
      rating: 5
    },
    {
      name: "Usman Ali",
      text: "Best decision we made for our child's education. Highly recommend Holistic Nibras to all parents.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg" style={{ fontFamily: "Playfair Display" }}>HN</span>
            </div>
            <h1 className="text-xl font-bold text-primary" style={{ fontFamily: "Playfair Display" }}>Holistic Nibras</h1>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-foreground hover:text-primary transition-colors">About</a>
            <a href="#curriculum" className="text-foreground hover:text-primary transition-colors">Curriculum</a>
            <a href="#features" className="text-foreground hover:text-primary transition-colors">Features</a>
            <a href="#reviews" className="text-foreground hover:text-primary transition-colors">Reviews</a>
          </div>
          <Button className="bg-accent hover:bg-accent/90 text-accent-foreground" style={{ fontFamily: "Poppins" }}>
            Admission
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 z-0">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433367106/3QoQhNS9RWBTY6AnhiuRHD/hero-children-learning-kjPr3MZPacfTEYzdiNjefp.webp"
            alt="Children learning"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-background/60 to-background/40"></div>
        </div>

        <div className="container relative z-10">
          <div className="max-w-2xl">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 text-foreground" style={{ fontFamily: "Playfair Display" }}>
              Nurturing Young Minds, Empowering Futures
            </h2>
            <p className="text-lg md:text-xl text-foreground/80 mb-8 leading-relaxed">
              Welcome to Holistic Nibras, where education transcends academics. We foster holistic development through innovative teaching, nurturing environments, and a commitment to every child's unique potential.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground" style={{ fontFamily: "Poppins" }}>
                Explore Admissions <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary/5" style={{ fontFamily: "Poppins" }}>
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 md:py-32 bg-card">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-4xl md:text-5xl font-bold mb-6 text-foreground" style={{ fontFamily: "Playfair Display" }}>
                About Holistic Nibras
              </h3>
              <p className="text-foreground/70 mb-4 leading-relaxed">
                Founded with a vision to revolutionize education in Islamabad, Holistic Nibras is a premier private educational institution dedicated to holistic development. Our mission is to create a nurturing environment where every student flourishes academically, emotionally, and socially.
              </p>
              <p className="text-foreground/70 mb-6 leading-relaxed">
                Located in the heart of F-11/4, Islamabad, we combine innovative pedagogy with state-of-the-art facilities to provide an exceptional learning experience. Our experienced educators and supportive community ensure that each child receives personalized attention and guidance.
              </p>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                  <span className="text-foreground/80">Experienced, qualified educators</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                  <span className="text-foreground/80">Modern facilities and learning spaces</span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
                  <span className="text-foreground/80">Holistic development approach</span>
                </div>
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433367106/3QoQhNS9RWBTY6AnhiuRHD/hero-school-campus-bEKfbMXYingtnaphSRHHUA.webp"
                alt="School campus"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Curriculum Section */}
      <section id="curriculum" className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h3 className="text-4xl md:text-5xl font-bold mb-4 text-foreground" style={{ fontFamily: "Playfair Display" }}>
              Our Curriculum
            </h3>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              We offer diverse, innovative learning pathways designed to develop critical thinking, creativity, and global citizenship.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: BookOpen,
                title: "Cambridge Curriculum",
                description: "Internationally recognized curriculum emphasizing critical thinking and comprehensive subject knowledge."
              },
              {
                icon: Sparkles,
                title: "Project-Based Learning",
                description: "Real-world problem-solving through collaborative projects that develop practical skills and innovation."
              },
              {
                icon: Users,
                title: "STEM Education",
                description: "Integrated science, technology, engineering, and mathematics for 21st-century skill development."
              }
            ].map((item, idx) => (
              <Card key={idx} className="p-8 bg-card border-border hover:shadow-lg transition-shadow duration-300">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                  <item.icon className="w-6 h-6 text-accent" />
                </div>
                <h4 className="text-xl font-bold mb-3 text-foreground" style={{ fontFamily: "Poppins" }}>
                  {item.title}
                </h4>
                <p className="text-foreground/70 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            ))}
          </div>

          <div className="mt-16 bg-gradient-to-r from-primary/5 to-accent/5 rounded-lg p-8 md:p-12 border border-border">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h4 className="text-2xl font-bold mb-4 text-foreground" style={{ fontFamily: "Playfair Display" }}>
                  Arts Integration
                </h4>
                <p className="text-foreground/70 mb-4 leading-relaxed">
                  Through arts integration, students explore their creativity, express themselves, and develop essential skills such as communication and collaboration.
                </p>
                <p className="text-foreground/70 leading-relaxed">
                  We believe that artistic expression enhances overall learning and contributes to the holistic development of our students.
                </p>
              </div>
              <div className="h-64 rounded-lg overflow-hidden">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433367106/3QoQhNS9RWBTY6AnhiuRHD/abstract-growth-pattern-WxDPPJXSieP6US5Sn5b9Vn.webp"
                  alt="Growth pattern"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 md:py-32 bg-card">
        <div className="container">
          <h3 className="text-4xl md:text-5xl font-bold mb-16 text-foreground text-center" style={{ fontFamily: "Playfair Display" }}>
            Why Choose Holistic Nibras?
          </h3>

          <div className="grid md:grid-cols-2 gap-8">
            {[
              {
                title: "Empowering Future Leaders",
                description: "Our school prepares students to be engaged members of society who can make a positive impact on the world."
              },
              {
                title: "Focus on Well-Rounded Individuals",
                description: "We go beyond academics, aiming to develop the whole student – intellectually, socially, and emotionally."
              },
              {
                title: "Supportive & Inclusive Environment",
                description: "We create a safe space where students can thrive and learn important life skills like empathy and resilience."
              },
              {
                title: "Experienced Educators",
                description: "Our team of qualified, passionate educators are committed to nurturing each student's unique potential."
              }
            ].map((feature, idx) => (
              <div key={idx} className="p-8 border border-border rounded-lg hover:border-primary transition-colors duration-300">
                <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center mb-4">
                  <span className="text-accent font-bold" style={{ fontFamily: "Poppins" }}>{idx + 1}</span>
                </div>
                <h4 className="text-xl font-bold mb-3 text-foreground" style={{ fontFamily: "Poppins" }}>
                  {feature.title}
                </h4>
                <p className="text-foreground/70 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h3 className="text-4xl md:text-5xl font-bold mb-4 text-foreground" style={{ fontFamily: "Playfair Display" }}>
              Parent & Student Reviews
            </h3>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Hear from our satisfied parents and students about their experience at Holistic Nibras.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {reviews.map((review, idx) => (
              <Card key={idx} className="p-8 bg-card border-border hover:shadow-lg transition-shadow duration-300">
                <div className="flex gap-1 mb-4">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-foreground/70 mb-6 leading-relaxed italic">
                  "{review.text}"
                </p>
                <div>
                  <h5 className="font-bold text-foreground" style={{ fontFamily: "Poppins" }}>
                    {review.name}
                  </h5>
                  <p className="text-sm text-foreground/60">Parent</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Information Section */}
      <section className="py-20 md:py-32 bg-card">
        <div className="container">
          <div className="text-center mb-16">
            <h3 className="text-4xl md:text-5xl font-bold mb-4 text-foreground" style={{ fontFamily: "Playfair Display" }}>
              Get in Touch
            </h3>
            <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
              Have questions about admissions or want to learn more about our programs? Reach out to us through any of the following channels.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mx-auto mb-4">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <h4 className="font-bold text-foreground mb-2" style={{ fontFamily: "Poppins" }}>Address</h4>
              <p className="text-foreground/70">House No. 14, Main Nazim-ud-din Road, F-11/4, Islamabad, Pakistan</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mx-auto mb-4">
                <Phone className="w-6 h-6 text-accent" />
              </div>
              <h4 className="font-bold text-foreground mb-2" style={{ fontFamily: "Poppins" }}>Phone</h4>
              <p className="text-foreground/70">+92 332 8407913</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center mx-auto mb-4">
                <Mail className="w-6 h-6 text-accent" />
              </div>
              <h4 className="font-bold text-foreground mb-2" style={{ fontFamily: "Poppins" }}>Email</h4>
              <p className="text-foreground/70">info@holisticnibras.edu.pk</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h5 className="font-bold text-foreground mb-4" style={{ fontFamily: "Playfair Display" }}>Holistic Nibras</h5>
              <p className="text-foreground/70 text-sm">Nurturing young minds and empowering futures through holistic education.</p>
            </div>
            <div>
              <h5 className="font-bold text-foreground mb-4" style={{ fontFamily: "Poppins" }}>Quick Links</h5>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#about" className="hover:text-primary transition-colors">About</a></li>
                <li><a href="#curriculum" className="hover:text-primary transition-colors">Curriculum</a></li>
                <li><a href="#features" className="hover:text-primary transition-colors">Features</a></li>
                <li><a href="#reviews" className="hover:text-primary transition-colors">Reviews</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-foreground mb-4" style={{ fontFamily: "Poppins" }}>Contact</h5>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li>+92 332 8407913</li>
                <li>F-11/4, Islamabad</li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-foreground mb-4" style={{ fontFamily: "Poppins" }}>Follow Us</h5>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="https://instagram.com/holistic.nibras" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">Instagram</a></li>
                <li><a href="https://facebook.com/HolisticSchoolSystem" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-foreground/60 text-sm">
            <p>&copy; 2026 Holistic Nibras. All rights reserved. | Empowering Education, Nurturing Growth</p>
            <p className="mt-2">Made by <span className="font-semibold text-foreground">Uzayr Shoaib</span></p>
          </div>
        </div>
      </footer>
    </div>
  );
}
